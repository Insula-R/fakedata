I file contenuti nella presente cartella contengono dei dati inventati per un
ipotetico studio sperimentale utilizzato come esempio in alcuni post del blog
www.insular.it. I due file riportano gli stessi dati disposti in modo diverso.

Di seguito si riporta la descrizione dell'ipotetico esperimento.

In un laboratorio di psicofisiologia del sonno si stanno testando gli effetti
di una nuova psicoterapia (PT) e di un trattamento di tipo farmacologico (FT)
per la cura dell'insonnia. Sono state selezionate 10 persone insonni con pro-
blemi nella fase di addormentamento: 5 vengono trattate con PT e 5 con FT. Il
giorno prima dell'inizio del trattamento (tempo 0), a 30 giorni e infine a 60
giorni viene registrato il numero di ore dormite da ogni individuo.
